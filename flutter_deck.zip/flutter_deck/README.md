# flutter_deck

    engine/               deck_engine package: reusable across every talk
    talks/demo/           tiny example deck (engine features only)
    talks/mouse_huddle/   the Raam et al. 2026 presentation

Each talk is its own Flutter app:

    cd talks/mouse_huddle
    flutter create .       # once, to generate the platform folders
    flutter run -d macos   # or windows, linux, chrome

## Controls

    click  →  Space  PageDown     next step, then next slide
    ←  PageUp                     previous step, then previous slide
    ↓ / ↑                         skip to next / previous slide
    R                             restart current slide
    Home / End                    first / last slide

## Click-controlled animation

    Slide(
      steps: 3,                       // three clicks before the next slide
      builder: (context) => Column(children: [
        StageBuilder(                 // stage runs 0 → 3, eased, as you click
          builder: (context, stage) => CustomPaint(painter: MyPainter(stage)),
        ),
        Anim(step: 2, child: Text('appears on the second click')),
      ]),
    )

## Copying text off a slide

Slide text sits in real `Text` widgets inside a `SelectionArea`, so drag
across it to select and use Ctrl/Cmd-C, or right-click for the copy menu.
Right-click is deliberately not bound to "previous" for this reason — use
the left arrow instead.

Labels drawn inside a `CustomPaint` (axis ticks, the C / NC marks, the
contact counts) are painted pixels, not text, so they cannot be selected.

## Jumping to a step

A slide can offer its own targets instead of making the presenter click
through in order:

    final timeline = SlideTimeline.of(context);
    GestureDetector(
      onTap: () => timeline.goToStep(3),   // animates there from anywhere
      child: ...,
    )

A tap handler inside the slide wins over the deck's tap-to-advance, so the
target jumps rather than stepping. The state strip on the huddle-states
slide works this way.

## Exporting every slide as a PNG

    flutter run -d macos -t lib/export.dart

It walks the deck in order, fast-forwards each slide to its finished state
— main timeline at its end, every click taken — captures it, and quits.
Files land in `export/` as `slide_01.png`, `slide_02.png`, and so on, ready
to drop into PowerPoint, Keynote or a PDF.

    --dart-define=out=/some/path    where to write      (default: export/)
    --dart-define=scale=2           pixels per logical  (default: 2 -> 4K)
    --dart-define=settle=500        ms per slide before the shutter

Raise `settle` if a figure panel comes out blank: that is the image still
decoding. Desktop only — it writes files with dart:io.
