import 'dart:io';
import 'dart:ui' as ui;

import 'package:deck_engine/deck_engine.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/scheduler.dart';

import 'main.dart' show deckSlides;
import 'theme.dart';

// ---------------------------------------------------------------------------
// Writes every slide to a PNG, in deck order, then quits.
//
//   flutter run -d macos -t lib/export.dart
//
// Options, all optional:
//   --dart-define=out=/some/path    where to write      (default: export/)
//   --dart-define=scale=2           pixels per logical  (default: 2 → 4K)
//   --dart-define=settle=500        ms to wait per slide before capturing
//
// Each slide is mounted, fast-forwarded to its finished state — main
// timeline at its end, every click taken — and captured. So a slide with
// five clicks exports as the picture you would see after the fifth.
//
// Desktop only: it writes files with dart:io, which the web build has no
// equivalent for. Running it on macOS or Windows exports a deck you can
// then drop into PowerPoint, Keynote or a PDF.
// ---------------------------------------------------------------------------

const _outDir = String.fromEnvironment('out', defaultValue: 'export');
const _scale = int.fromEnvironment('scale', defaultValue: 2);
const _settleMs = int.fromEnvironment('settle', defaultValue: 500);

/// The canvas every slide is laid out on, matching the deck's own.
const _canvas = Size(1920, 1080);

void main() {
  runApp(const _ExporterApp());
}

class _ExporterApp extends StatefulWidget {
  const _ExporterApp();

  @override
  State<_ExporterApp> createState() => _ExporterAppState();
}

class _ExporterAppState extends State<_ExporterApp> {
  final _boundary = GlobalKey();
  final _controller = DeckController();
  String _status = 'starting…';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final dir = Directory(_outDir)..createSync(recursive: true);
    final digits = deckSlides.length.toString().length;

    for (var i = 0; i < deckSlides.length; i++) {
      _report('slide ${i + 1} of ${deckSlides.length}');
      _controller.goTo(i);
      await _frame();

      // Run the slide to its end state and stop every clock, so the
      // capture is deterministic rather than whatever frame we land on.
      _controller.timeline?.settle();
      await _frame();

      // Give images and shaders time to come in before the shutter.
      await Future<void>.delayed(const Duration(milliseconds: _settleMs));
      await _frame();

      final file = File(
        '${dir.path}/slide_${(i + 1).toString().padLeft(digits, '0')}.png',
      );
      file.writeAsBytesSync(await _capture());
      stdout.writeln('wrote ${file.path}');
    }

    _report('done — ${deckSlides.length} slides in ${dir.absolute.path}');
    stdout.writeln('\nExported ${deckSlides.length} slides to '
        '${dir.absolute.path}');
    await Future<void>.delayed(const Duration(milliseconds: 300));
    exit(0);
  }

  Future<List<int>> _capture() async {
    final boundary =
        _boundary.currentContext!.findRenderObject() as RenderRepaintBoundary;
    final image = await boundary.toImage(pixelRatio: _scale.toDouble());
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    return data!.buffer.asUint8List();
  }

  /// Waits for one painted frame.
  Future<void> _frame() async {
    await SchedulerBinding.instance.endOfFrame;
    await Future<void>.delayed(Duration.zero);
  }

  void _report(String message) {
    if (mounted) setState(() => _status = message);
  }

  @override
  Widget build(BuildContext context) {
    // The deck is laid out at full size inside the boundary and merely
    // shown scaled, so the capture is 1920 × 1080 × scale whatever the
    // window happens to be.
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Stack(
        children: [
          Positioned.fill(
            child: FittedBox(
              child: RepaintBoundary(
                key: _boundary,
                child: SizedBox.fromSize(
                  size: _canvas,
                  child: Deck(
                    theme: talkTheme,
                    slides: deckSlides,
                    controller: _controller,
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: ColoredBox(
              color: const Color(0xCC000000),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Text(
                  'exporting: $_status',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
