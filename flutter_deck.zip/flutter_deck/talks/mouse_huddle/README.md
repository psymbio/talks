# mouse_huddle

Talk on Raam et al., *Cortical regulation of collective social dynamics
during environmental challenge*, Nat Neurosci 29, 901–914 (2026).

    flutter create .          # once, to generate the platform folders
    flutter run -d macos      # or windows, linux, chrome

    lib/main.dart        the slide list, with the click count per slide
    lib/states.dart      the five group-huddle configurations (Fig. 1b)
    lib/slides/          one file per section of the talk
    lib/widgets/         slide frame, cards, the mouse and arena painters
    lib/theme.dart       palette and the Open Sans type scale
    fonts/               IBM Plex Sans (SIL OFL 1.1)
    images/              published figure panels

## Figure panels

Nineteen slides load a crop from `images/`; `images/README.txt` lists the
exact names. Fig. 1a,b, 1i, 2a,b, 3a and 3j are drawn in code instead, so
they need no file, and a name the deck cannot find shows a labelled box
rather than crashing.

The folder is declared as an asset, so adding a file is enough — then call
`FigureImage('my_panel.png')` from `lib/widgets/frame.dart`.

## Selecting text

Slides are wrapped in a `SelectionArea`, so any text rendered as a widget
can be dragged over, selected and copied. Labels drawn inside a painter —
axis ticks, contact counts — are pixels, not text, so they cannot be.
Dragging across text selects instead of advancing; a plain click and the
arrow keys still move the deck.

## Controls

    click  →  Space  PageDown     next step, then next slide
    ←  PageUp                     previous step, then previous slide
    ↓ / ↑                         skip a whole slide
    R                             restart the current slide

## Changing the title animation

`_titleStops` at the top of `lib/slides/intro.dart` lists one stop per click
position — a group state and the temperature shown with it. Two stops give
one click, three give two, and so on; `steps:` reads the length, so only the
list needs editing. `stepDuration` on that same `Slide` sets how slowly each
click plays.

## The cover loop

The title slide animates on its own and never waits for a click.
`_titleStops` in `lib/slides/intro.dart` lists the states it walks through,
`_loopDuration` sets how long one pass takes (it then plays back, so a full
cycle is twice that) and `_loopHold` how much of each leg is spent resting
on a stop.

## Copying text off a slide

Slide text sits in real `Text` widgets inside a `SelectionArea`, so drag
across it to select and use Ctrl/Cmd-C, or right-click for the copy menu.
Right-click is deliberately not bound to "previous" for this reason — use
the left arrow instead.

Labels drawn inside a `CustomPaint` (axis ticks, the C / NC marks, the
contact counts) are painted pixels, not text, so they cannot be selected.

## Exporting every slide as a PNG

In the browser, which is how this deck is usually run:

    flutter run -d web-server --web-hostname 0.0.0.0 --web-port 8080 \
      -t lib/export_web.dart

Open the page, press Export, and you get one `slides.zip` holding
`slide_01.png` … `slide_38.png`. A browser cannot write into a folder, so
a zip is as close as it gets. Needs the CanvasKit renderer, which is the
default.

On desktop, writing the files straight into a folder:

    flutter run -d macos -t lib/export.dart

It walks the deck in order, fast-forwards each slide to its finished state
— main timeline at its end, every click taken — captures it, and quits.
Files land in `export/` as `slide_01.png`, `slide_02.png`, and so on, ready
to drop into PowerPoint, Keynote or a PDF.

    --dart-define=out=/some/path    where to write      (default: export/)
    --dart-define=scale=2           pixels per logical  (default: 2 -> 4K)
    --dart-define=settle=500        ms per slide before the shutter

Raise `settle` if a figure panel comes out blank: that is the image still
decoding. Desktop only — it writes files with dart:io.
