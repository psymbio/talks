Figure crops go in this folder. The deck looks for exactly these names:

  fig_1_c_d_e.png    fig_1_f_g_h.png    fig_1_j_k_l.png
  fig_2_c_d_e.png    fig_2_f_to_q.png   fig_2_r_to_y.png
  fig_3_b_c.png      fig_3_d_to_i.png   fig_3_j_to_n.png   fig_3_o_to_x.png
  fig_4_d_e.png      fig_4_f_to_j.png   fig_4_k_to_n.png
  fig_5_a_to_d.png   fig_5_e_to_h.png   fig_5_i_to_r.png
  fig_6_c_to_h.png   fig_6_i_to_o.png   fig_6_p_to_v.png

Fig. 1a,b, 1i, 2a,b, 3a and 3j are drawn in code instead, so they need no
file. A name the deck asks for but cannot find shows a labelled box rather
than crashing, so the deck still runs with panels missing.

The whole folder is declared as an asset in pubspec.yaml: adding a file
here is enough, and FigureImage('my_panel.png') will pick it up.
